alert("¡Bienvenido a la página de Neymar Jr!");

function mostrarMensaje() {
    alert("Neymar Jr. es una estrella del fútbol brasileño. ⚽");
}

function cambiarColor() {
    document.body.style.backgroundColor = "#d9f2d9";
}

function mostrarFecha() {
    let fecha = new Date();
    alert("Hoy es: " + fecha.toLocaleDateString());
} 